package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectAppApplication.class, args);
	}

}
